setwd("C:/Users/LOVE UMB/Desktop/NexFord Uni/BAN6420/Mod 4")
# Install the required package if not already installed
if (!requireNamespace("png", quietly = TRUE)) {
  install.packages("png")
}

library(png)
library(grid)
# Load the image
img <- readPNG("most_watched_genres.png")

# Display the image
grid.raster(img)
