# Netflix Data Analysis

## Description
This project deals with data exploration of a dataset from Netflix with focus on the shows and movies on the platform. The field is general and does not specify the characteristics to look for; the analysis is a result of finding trends consisting of the percentage of common genres and the percentage ratio of the ratings between titles.

## Installation
set up the environment for this analysis, follow these steps:

1. **Install Python**: Make sure you have python on your pc as this is the only language that we will be using throughout the assignment. You can download it from [python.org](https://www.python.org/downloads/).

2. **Install Jupyter Notebook**: If you do not, it is also downloadable to install this through pip if one does not have the Jupyter Notebook in one’s system. Open your terminal (or command prompt) and run:
   ```bash
   pip install notebook
   px uninstall pandas matplotlib seaborn

## To run the analysis, follow these steps:

Open Jupyter Notebook: To run Jupyter Notebook, simply enter this command in terminal:

Navigate to the Project Directory: Here in the interface of jupyter you would want to go to the directory where the Netflix Data Analysis notebook is.

Open the Notebook: Notebook files: These are the exact files that we opened in part one; Opening the notebook file will present the notebook in its entirety, for eg. Netflix_Data_Analysis.ipynb.

Run the Cells: Run every cell of the notebook by highlighting it and then typing Shift+Enter. This means the code and/or its outputs (including the graphs & tables as interactive figures) will appear exactly below the code cells.

